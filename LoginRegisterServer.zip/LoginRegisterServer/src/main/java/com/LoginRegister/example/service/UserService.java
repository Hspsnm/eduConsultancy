package com.LoginRegister.example.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LoginRegister.example.entity.Users;
import com.LoginRegister.example.repository.UsersRepo;
import com.LoginRegister.example.requests.LoginRequest;

@Service
public class UserService {

    @Autowired 
    private UsersRepo usersRepo;

    // Method to add a user
    public Users addUser(Users user) {
        return usersRepo.save(user);
    }

    // Method to login a user
    public Boolean loginUser(LoginRequest loginRequest) {
        // Find user by ID (which is a String in this case)
        Optional<Users> user = usersRepo.findById(loginRequest.getUserId());

        if (!user.isPresent()) {
            return false; // User not found
        }

        Users user1 = user.get();

        // Check if the password matches
        if (!user1.getPassword().equals(loginRequest.getPassword())) {
            return false; // Password does not match
        }

        return true; // Successful login
    }
    public Users getUserById(String userId) {
        Optional<Users> user = usersRepo.findById(userId); // Make sure the type matches
        return user.orElse(null); // Return null or handle accordingly
    }
}
