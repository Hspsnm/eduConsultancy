package com.LoginRegister.example.repository;

import com.LoginRegister.example.entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UsersRepo extends JpaRepository<Users, String> {

    // Custom method for finding user by ID
    List<Users> findByUserId(int userId);

    // Built-in methods from JpaRepository cover:
    // saveUser -> save()
    // getUsers -> findAll()
    // deleteUser -> deleteById() or delete()
    // updateUser -> save()
}
