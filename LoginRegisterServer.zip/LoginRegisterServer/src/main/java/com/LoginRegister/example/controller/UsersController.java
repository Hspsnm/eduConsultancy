package com.LoginRegister.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.LoginRegister.example.entity.Users;
import com.LoginRegister.example.requests.LoginRequest;
import com.LoginRegister.example.service.UserService;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping(value = "/api")
public class UsersController {

    @Autowired
    private UserService userService;

    // Primary User-related functionalities
    @PostMapping("/addUser")
    public Users addUser(@RequestBody Users user) {
        return userService.addUser(user);
    }

    @PostMapping("/loginUser")
    public Boolean loginUser(@RequestBody LoginRequest loginRequest) {
        return userService.loginUser(loginRequest);
    }

    @GetMapping("/getUser")
    public Users getUser(@RequestParam("userId") String userId) {
        return userService.getUserById(userId);
    }

    // Additional User-related functionalities (formerly Student functionalities)
    @PostMapping("/saveUser")
    public ResponseEntity<Boolean> saveUser(@RequestBody Users user) {
        boolean isSaved = userService.saveUser(user);
        return ResponseEntity.status(isSaved ? HttpStatus.CREATED : HttpStatus.BAD_REQUEST).body(isSaved);
    }

    @GetMapping("/usersList")
    public ResponseEntity<List<Users>> getAllUsers() {
        List<Users> users = userService.getUsers();
        return ResponseEntity.ok(users);
    }

    @DeleteMapping("/deleteUser/{userId}")
    public ResponseEntity<Boolean> deleteUser(@PathVariable("userId") int userId) {
        boolean isDeleted = userService.deleteUserById(userId);
        return ResponseEntity.status(isDeleted ? HttpStatus.OK : HttpStatus.NOT_FOUND).body(isDeleted);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Users>> getUserById(@PathVariable("userId") int userId) {
        List<Users> user = userService.getUserById(userId);
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
    }

    @PostMapping("/updateUser/{userId}")
    public ResponseEntity<Boolean> updateUser(@RequestBody Users user, @PathVariable("userId") int userId) {
        user.setUserId(userId);
        boolean isUpdated = userService.updateUser(user);
        return ResponseEntity.status(isUpdated ? HttpStatus.OK : HttpStatus.BAD_REQUEST).body(isUpdated);
    }
}
