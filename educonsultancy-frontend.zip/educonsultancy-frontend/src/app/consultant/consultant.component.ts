import { Component } from '@angular/core';

@Component({
  selector: 'app-consultant',
  standalone: true,
  imports: [],
  templateUrl: './consultant.component.html',
  styleUrl: './consultant.component.css'
})
export class ConsultantComponent {

}
