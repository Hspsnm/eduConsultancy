package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.model.User;
import com.service.UserServiceImpl;

import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserServiceImpl userService;

    @PostMapping("/signup")
    public User signUpUser(@RequestBody User user) throws Exception {
        return userService.signUpUser(user);
    }

    @GetMapping("/check-username")
    public Map<String, Object> checkUsernameAvailability(@RequestParam String username) {
        boolean available = userService.isUserNameAvailable(username);
        String message = available ? "Username is available" : "Username is already taken";
        Map<String, Object> response = new HashMap<>();
        response.put("available", available);
        response.put("message", message);
        return response;
    }

    @PostMapping("/login")
    public User loginUser(@RequestParam String email, @RequestParam String password) throws Exception {
        return userService.loginUser(email, password);
    }
}
