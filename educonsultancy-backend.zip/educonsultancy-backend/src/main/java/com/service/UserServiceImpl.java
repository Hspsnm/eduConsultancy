package com.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.UserRepository;
import com.model.User;

@Service
public class UserServiceImpl {

    @Autowired
    private UserRepository userRepository;

    public User signUpUser(User user) throws Exception {
        if (userRepository.findByUserName(user.getUserName()).isPresent()) {
            throw new Exception("Username already exists");
        }
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            throw new Exception("Email already exists");
        }
        return userRepository.save(user);
    }

    public User loginUser(String email, String password) throws Exception {
        Optional<User> user = userRepository.findByEmail(email);
        if (user.isPresent() && user.get().getPassword().equals(password)) {
            return user.get();
        } else {
            throw new Exception("Invalid email or password");
        }
    }

    public boolean isUserNameAvailable(String userName) {
        return userRepository.findByUserName(userName).isEmpty();
    }
}
