package com.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.model.User;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Integer> {
    Optional<User> findByUserName(String userName);  // To check if the user already exists
    Optional<User> findByEmail(String email);        // For email login
}
